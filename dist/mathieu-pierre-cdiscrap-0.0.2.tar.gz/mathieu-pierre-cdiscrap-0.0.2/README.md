# cdiscrap

Python package capable of raising the price of any product on the site www.cdiscount.com

## Install
```
$ pip install cdiscrap
```

## Usage
```
$ python
>>> from parse_price import sku_to_price, sku, price
>>> sku('YOUR_SKU')
```

## Tests
```
$ pip install pytest

$ pytest
```


python setup.py bdist_wheel sdist 
ls dist
pip install twine
twine upload dist/*
user : mathieu-pierre
pass : b.6+@&#v*mApn+7
pip install mathieu-pierre-cdiscrap
