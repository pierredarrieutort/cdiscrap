# cdiscrap
Python package capable of raising the price of any product on the site www.cdiscount.com
